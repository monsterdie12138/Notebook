#include <iostream>
#include <vector>

#include "CGL/vector2D.h"

#include "mass.h"
#include "rope.h"
#include "spring.h"

namespace CGL {

    Rope::Rope(Vector2D start, Vector2D end, int num_nodes, float node_mass, float k, vector<int> pinned_nodes)
    {
        // TODO (Part 1): Create a rope starting at `start`, ending at `end`, and containing `num_nodes` nodes.

//        Comment-in this part when you implement the constructor
//        for (auto &i : pinned_nodes) {
//            masses[i]->pinned = true;
//        }
        Vector2D delta = (end - start) / (num_nodes - 1);
        for (int i = 0; i < num_nodes; i++)
        {
            Vector2D node_pos = start + i * delta;
            Mass* mass = new Mass(node_pos, node_mass, false);
            masses.push_back(mass);
            if (i > 0)
            {
                Spring* spring = new Spring(masses[i-1], masses[i], k);
                springs.push_back(spring);
            }
        }
        for (int i: pinned_nodes)
        {
            masses[i]->pinned = true;
        }
    }

    void Rope::simulateEuler(float delta_t, Vector2D gravity)
    {
        for (auto &s : springs)
        {
            // TODO (Part 2): Use Hooke's law to calculate the force on a node
            Vector2D pos_a = s->m1->position;
            Vector2D pos_b = s->m2->position;
            float real_length = std::sqrt((pos_a - pos_b).norm2());
            Vector2D force = s->k * (pos_b - pos_a) * (real_length - s->rest_length) / real_length;
            s->m1->forces += force;
            s->m2->forces -= force;
        }

        for (auto &m : masses)
        {
            if (!m->pinned)
            {
                // TODO (Part 2): Add the force due to gravity, then compute the new velocity and position
                m->forces += gravity;
                Vector2D a_t = m-> forces / m->mass;
                Vector2D v_tt = m->velocity + a_t * delta_t;
                Vector2D x_tt = m->position + v_tt * delta_t;
                m->velocity = v_tt * 0.99995;
                m->position = x_tt;
                // TODO (Part 2): Add global damping
            }

            // Reset all forces on each mass
            m->forces = Vector2D(0, 0);
        }
    }

    void Rope::simulateVerlet(float delta_t, Vector2D gravity)
    {
        for (auto &s : springs)
        {
            // TODO (Part 3): Simulate one timestep of the rope using explicit Verlet （solving constraints)
            Vector2D delta = s->m2->position - s->m1->position;
            float dist = sqrt(delta.norm2());
            float diff = (dist - s->rest_length) / dist;
            Vector2D correction = delta * 0.5f * diff;
            if (!s->m1->pinned) s->m1->position += correction;
            if (!s->m2->pinned) s->m2->position -= correction;
        }

        for (auto &m : masses)
        {
            if (!m->pinned)
            {
                Vector2D temp_position = m->position;
                // TODO (Part 3.1): Set the new position of the rope mass
                Vector2D a_t = gravity / m->mass;
                Vector2D x_ = m->last_position;
                Vector2D x_t = m->position;
                Vector2D x_tt = x_t + (1 - 0.00005) * (x_t - x_) + a_t * delta_t * delta_t;
                m->position = x_tt;
                m->last_position = temp_position;
                // TODO (Part 4): Add global Verlet damping
            }
        }
    }
}
