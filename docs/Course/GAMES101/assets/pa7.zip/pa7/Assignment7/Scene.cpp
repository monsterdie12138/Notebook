//
// Created by Göksu Güvendiren on 2019-05-14.
//

#include "Scene.hpp"


void Scene::buildBVH() {
    printf(" - Generating BVH...\n\n");
    this->bvh = new BVHAccel(objects, 1, BVHAccel::SplitMethod::NAIVE);
}

Intersection Scene::intersect(const Ray &ray) const
{
    return this->bvh->Intersect(ray);
}

void Scene::sampleLight(Intersection &pos, float &pdf) const
{
    float emit_area_sum = 0;
    for (uint32_t k = 0; k < objects.size(); ++k) {
        if (objects[k]->hasEmit()){
            emit_area_sum += objects[k]->getArea();
        }
    }
    float p = get_random_float() * emit_area_sum;
    emit_area_sum = 0;
    for (uint32_t k = 0; k < objects.size(); ++k) {
        if (objects[k]->hasEmit()){
            emit_area_sum += objects[k]->getArea();
            if (p <= emit_area_sum){
                objects[k]->Sample(pos, pdf);
                break;
            }
        }
    }
}

bool Scene::trace(
        const Ray &ray,
        const std::vector<Object*> &objects,
        float &tNear, uint32_t &index, Object **hitObject)
{
    *hitObject = nullptr;
    for (uint32_t k = 0; k < objects.size(); ++k) {
        float tNearK = kInfinity;
        uint32_t indexK;
        Vector2f uvK;
        if (objects[k]->intersect(ray, tNearK, indexK) && tNearK < tNear) {
            *hitObject = objects[k];
            tNear = tNearK;
            index = indexK;
        }
    }


    return (*hitObject != nullptr);
}

// Implementation of Path Tracing
Vector3f Scene::castRay(const Ray &ray, int depth) const
{
    // Part0
    Intersection inter_p = intersect(ray);
    if (!inter_p.happened) return backgroundColor;
    Vector3f pos_p = inter_p.coords;
    Vector3f N = inter_p.normal.normalized();
    Material* m = inter_p.m;
    Vector3f wo = ray.direction;
    if (m->hasEmission()) return m->getEmission();

    // Part1
    Vector3f L_dir(0.0, 0.0, 0.0);
    Intersection inter_x;
    float pdf_light;
    sampleLight(inter_x, pdf_light);
    Vector3f pos_x = inter_x.coords;
    Vector3f ws = (pos_x - pos_p).normalized();
    Vector3f NN = inter_x.normal.normalized();
    Vector3f emit = inter_x.emit;
    Ray ray_px(pos_p, ws);
    float d_actual = intersect(ray_px).distance;
    float d_imagine = std::sqrt((pos_x.x - pos_p.x) * (pos_x.x - pos_p.x) + (pos_x.y - pos_p.y) * (pos_x.y - pos_p.y) + (pos_x.z - pos_p.z) *(pos_x.z - pos_p.z));
    if (d_actual - d_imagine > -0.01)
    {
        float ws_dot_N = ws.x * N.x + ws.y * N.y + ws.z * N.z;
        float ws_dot_NN = - (ws.x * NN.x + ws.y * NN.y + ws.z * NN.z);
        float dis_square = d_imagine * d_imagine;
            L_dir = emit * m->eval(wo, ws, N) * ws_dot_N * ws_dot_NN / dis_square / pdf_light;
    }

    // Part2
    Vector3f L_indir(0.0, 0.0, 0.0);
    std::random_device rd;
    std::mt19937 gen(rd());
    std::bernoulli_distribution dist(RussianRoulette);
    Vector3f wi = m->sample(wo, N).normalized(); // from p to q
    Ray ray_pq(pos_p, wi);
    Intersection inter_q = intersect(ray_pq);
    if (dist(gen) && inter_q.happened && !inter_q.m->hasEmission())
    {
        float wi_dot_N = wi.x * N.x + wi.y * N.y + wi.z * N.z;
        L_indir = castRay(ray_pq, depth) * m->eval(wo, wi, N) * wi_dot_N / m->pdf(wo, wi, N) / RussianRoulette;
    }
    
    // End
    return L_dir + L_indir;
}