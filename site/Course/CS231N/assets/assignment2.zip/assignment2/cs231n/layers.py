from builtins import range
import numpy as np


def affine_forward(x, w, b):
    """Computes the forward pass for an affine (fully connected) layer.

    The input x has shape (N, d_1, ..., d_k) and contains a minibatch of N
    examples, where each example x[i] has shape (d_1, ..., d_k). We will
    reshape each input into a vector of dimension D = d_1 * ... * d_k, and
    then transform it to an output vector of dimension M.

    Inputs:
    - x: A numpy array containing input data, of shape (N, d_1, ..., d_k)
    - w: A numpy array of weights, of shape (D, M)
    - b: A numpy array of biases, of shape (M,)

    Returns a tuple of:
    - out: output, of shape (N, M)
    - cache: (x, w, b)
    """
    out = None
    ###########################################################################
    # TODO: Copy over your solution from Assignment 1.                        #
    ###########################################################################
    N = x.shape[0] #the number of images
    x_flatten = x.reshape(N, -1) #reshape each image into a vector
    out = x_flatten.dot(w) + b #compute through affine layer
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    cache = (x, w, b)
    return out, cache


def affine_backward(dout, cache):
    """Computes the backward pass for an affine (fully connected) layer.

    Inputs:
    - dout: Upstream derivative, of shape (N, M)
    - cache: Tuple of:
      - x: Input data, of shape (N, d_1, ... d_k)
      - w: Weights, of shape (D, M)
      - b: Biases, of shape (M,)

    Returns a tuple of:
    - dx: Gradient with respect to x, of shape (N, d1, ..., d_k)
    - dw: Gradient with respect to w, of shape (D, M)
    - db: Gradient with respect to b, of shape (M,)
    """
    x, w, b = cache
    dx, dw, db = None, None, None
    ###########################################################################
    # TODO: Copy over your solution from Assignment 1.                        #
    ###########################################################################
    N = x.shape[0] #the number of images
    x_flatten = x.reshape(N, -1) #reshape each image into a vector
    dx = dout.dot(w.T).reshape(x.shape) #shape(N, d_1, ..., d_k)
    dw = x_flatten.T.dot(dout) #shape(D, M)
    db = dout.sum(axis=0) #shape(M,)
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    return dx, dw, db


def relu_forward(x):
    """Computes the forward pass for a layer of rectified linear units (ReLUs).

    Input:
    - x: Inputs, of any shape

    Returns a tuple of:
    - out: Output, of the same shape as x
    - cache: x
    """
    out = None
    ###########################################################################
    # TODO: Copy over your solution from Assignment 1.                        #
    ###########################################################################
    out = np.maximum(x, 0) #eliminate negative number elementwise
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    cache = x
    return out, cache


def relu_backward(dout, cache):
    """Computes the backward pass for a layer of rectified linear units (ReLUs).

    Input:
    - dout: Upstream derivatives, of any shape
    - cache: Input x, of same shape as dout

    Returns:
    - dx: Gradient with respect to x
    """
    dx, x = None, cache
    ###########################################################################
    # TODO: Copy over your solution from Assignment 1.                        #
    ###########################################################################
    local_gradient = (x > 0).astype(int) #type casting
    dx = dout * local_gradient
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    return dx


def softmax_loss(x, y):
    """Computes the loss and gradient for softmax classification.

    Inputs:
    - x: Input data, of shape (N, C) where x[i, j] is the score for the jth
      class for the ith input.
    - y: Vector of labels, of shape (N,) where y[i] is the label for x[i] and
      0 <= y[i] < C

    Returns a tuple of:
    - loss: Scalar giving the loss
    - dx: Gradient of the loss with respect to x
    """
    loss, dx = None, None

    ###########################################################################
    # TODO: Copy over your solution from Assignment 1.                        #
    ###########################################################################
    #compute the loss
    N = x.shape[0]
    scores = x.copy()
    scores -= np.max(scores, axis=1).reshape(-1, 1)
    p = np.exp(scores)
    p /= np.sum(p, axis=1).reshape(-1, 1)
    logp = np.log(p + 1e-12)
    loss = -np.sum(logp[np.arange(N), y])
    loss = loss / N

    #compute the gradient
    p_new = p.copy()
    p_new[np.arange(N), y] -= 1
    dx = p_new / N
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    return loss, dx


def batchnorm_forward(x, gamma, beta, bn_param):
    """Forward pass for batch normalization.

    During training the sample mean and (uncorrected) sample variance are
    computed from minibatch statistics and used to normalize the incoming data.
    During training we also keep an exponentially decaying running mean of the
    mean and variance of each feature, and these averages are used to normalize
    data at test-time.

    At each timestep we update the running averages for mean and variance using
    an exponential decay based on the momentum parameter:

    running_mean = momentum * running_mean + (1 - momentum) * sample_mean
    running_var = momentum * running_var + (1 - momentum) * sample_var

    Note that the batch normalization paper suggests a different test-time
    behavior: they compute sample mean and variance for each feature using a
    large number of training images rather than using a running average. For
    this implementation we have chosen to use running averages instead since
    they do not require an additional estimation step; the torch7
    implementation of batch normalization also uses running averages.

    Input:
    - x: Data of shape (N, D)
    - gamma: Scale parameter of shape (D,)
    - beta: Shift paremeter of shape (D,)
    - bn_param: Dictionary with the following keys:
      - mode: 'train' or 'test'; required
      - eps: Constant for numeric stability
      - momentum: Constant for running mean / variance.
      - running_mean: Array of shape (D,) giving running mean of features
      - running_var Array of shape (D,) giving running variance of features

    Returns a tuple of:
    - out: of shape (N, D)
    - cache: A tuple of values needed in the backward pass
    """
    mode = bn_param["mode"]
    eps = bn_param.get("eps", 1e-5)
    momentum = bn_param.get("momentum", 0.9)

    N, D = x.shape
    running_mean = bn_param.get("running_mean", np.zeros(D, dtype=x.dtype))
    running_var = bn_param.get("running_var", np.zeros(D, dtype=x.dtype))

    out, cache = None, None
    if mode == "train":
        #######################################################################
        # TODO: Implement the training-time forward pass for batch norm.      #
        # Use minibatch statistics to compute the mean and variance, use      #
        # these statistics to normalize the incoming data, and scale and      #
        # shift the normalized data using gamma and beta.                     #
        #                                                                     #
        # You should store the output in the variable out. Any intermediates  #
        # that you need for the backward pass should be stored in the cache   #
        # variable.                                                           #
        #                                                                     #
        # You should also use your computed sample mean and variance together #
        # with the momentum variable to update the running mean and running   #
        # variance, storing your result in the running_mean and running_var   #
        # variables.                                                          #
        #                                                                     #
        # Note that though you should be keeping track of the running         #
        # variance, you should normalize the data based on the standard       #
        # deviation (square root of variance) instead!                        #
        # Referencing the original paper (https://arxiv.org/abs/1502.03167)   #
        # might prove to be helpful.                                          #
        #######################################################################

        #compute the mean and variance
        mean = np.mean(x, axis=0)
        var = np.var(x, axis=0)

        #transform the original data
        x_norm = (x - mean) / np.sqrt(var + eps)
        out = x_norm * gamma + beta

        #update the running mean and running variance
        running_mean = momentum * running_mean + (1 - momentum) * mean
        running_var = momentum * running_var + (1 - momentum) * var

        #fill the cache
        cache = {
              'x': x,
              'x_norm': x_norm,
              'mean': mean,
              'var': var,
              'gamma': gamma,
              'beta': beta,
              'eps': eps
        }

        #######################################################################
        #                           END OF YOUR CODE                          #
        #######################################################################
    elif mode == "test":
        #######################################################################
        # TODO: Implement the test-time forward pass for batch normalization. #
        # Use the running mean and variance to normalize the incoming data,   #
        # then scale and shift the normalized data using gamma and beta.      #
        # Store the result in the out variable.                               #
        #######################################################################
        x_norm = (x - running_mean) / np.sqrt(running_var + eps)
        out = x_norm * gamma + beta
        #######################################################################
        #                          END OF YOUR CODE                           #
        #######################################################################
    else:
        raise ValueError('Invalid forward batchnorm mode "%s"' % mode)

    # Store the updated running means back into bn_param
    bn_param["running_mean"] = running_mean
    bn_param["running_var"] = running_var

    return out, cache


def batchnorm_backward(dout, cache):
    """Backward pass for batch normalization.

    For this implementation, you should write out a computation graph for
    batch normalization on paper and propagate gradients backward through
    intermediate nodes.

    Inputs:
    - dout: Upstream derivatives, of shape (N, D)
    - cache: Variable of intermediates from batchnorm_forward.

    Returns a tuple of:
    - dx: Gradient with respect to inputs x, of shape (N, D)
    - dgamma: Gradient with respect to scale parameter gamma, of shape (D,)
    - dbeta: Gradient with respect to shift parameter beta, of shape (D,)
    """
    dx, dgamma, dbeta = None, None, None
    ###########################################################################
    # TODO: Implement the backward pass for batch normalization. Store the    #
    # results in the dx, dgamma, and dbeta variables.                         #
    # Referencing the original paper (https://arxiv.org/abs/1502.03167)       #
    # might prove to be helpful.                                              #
    ###########################################################################

    #prepare variables
    N, D = dout.shape
    gamma = cache["gamma"]
    x_norm = cache["x_norm"]
    var = cache["var"]
    eps = cache["eps"]
    x = cache["x"]
    mean = cache["mean"]

    #first node: out = gamma * x_norm + beta
    dxnorm = dout * gamma #shape(N, D)
    dgamma = np.sum(dout * x_norm, axis=0) #shape(D,)
    dbeta = np.sum(dout, axis=0) #shape(D,)

    #second node: x_norm = (x - mean) / sqrt(var + eps)
    #path of direct x
    dxnorm_dx = 1 / np.sqrt(var + eps) #shape(D,)
    dx_xpath = dxnorm * dxnorm_dx
    #path of mean
    dxnorm_dmean = -1 / np.sqrt(var + eps) #shape(D,)
    dmean = np.sum(dxnorm * dxnorm_dmean, axis=0) #shape(D,)
    dmean_dx = 1 / N #scalar
    dx_meanpath = dmean * dmean_dx #shape(D,)
    #path of var
    dxnorm_dvar = -0.5 * (x - mean) * (var + eps) ** (-1.5) #shape(N, D)
    dvar = np.sum(dxnorm * dxnorm_dvar, axis=0) #shape(D,)
    dvar_dx = 2 * (x - mean) / N #shape(N, D)
    dx_varpath = dvar * dvar_dx #shape(N, D)
    #sum up the paths
    dx = dx_xpath + dx_meanpath + dx_varpath

    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################

    return dx, dgamma, dbeta


def batchnorm_backward_alt(dout, cache):
    """Alternative backward pass for batch normalization.

    For this implementation you should work out the derivatives for the batch
    normalizaton backward pass on paper and simplify as much as possible. You
    should be able to derive a simple expression for the backward pass.
    See the jupyter notebook for more hints.

    Note: This implementation should expect to receive the same cache variable
    as batchnorm_backward, but might not use all of the values in the cache.

    Inputs / outputs: Same as batchnorm_backward
    """
    dx, dgamma, dbeta = None, None, None
    ###########################################################################
    # TODO: Implement the backward pass for batch normalization. Store the    #
    # results in the dx, dgamma, and dbeta variables.                         #
    #                                                                         #
    # After computing the gradient with respect to the centered inputs, you   #
    # should be able to compute gradients with respect to the inputs in a     #
    # single statement; our implementation fits on a single 80-character line.#
    ###########################################################################
    
    #prepare variables
    N, D = dout.shape
    gamma = cache["gamma"]
    x_norm = cache["x_norm"]
    var = cache["var"]
    eps = cache["eps"]
    x = cache["x"]
    mean = cache["mean"]

    #compute gradients
    dxnorm = dout * gamma #shape(N, D)
    dgamma = np.sum(dout * x_norm, axis=0) #shape(D,)
    dbeta = np.sum(dout, axis=0) #shape(D,)
    dx =  1 / N / np.sqrt(var + eps) * (N * dxnorm - np.sum(dxnorm, axis=0) - (x - mean) / (var + eps) * np.sum(dxnorm * (x - mean), axis=0)) #just combine the three paths above

    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################

    return dx, dgamma, dbeta


def layernorm_forward(x, gamma, beta, ln_param):
    """Forward pass for layer normalization.

    During both training and test-time, the incoming data is normalized per data-point,
    before being scaled by gamma and beta parameters identical to that of batch normalization.

    Note that in contrast to batch normalization, the behavior during train and test-time for
    layer normalization are identical, and we do not need to keep track of running averages
    of any sort.

    Input:
    - x: Data of shape (N, D)
    - gamma: Scale parameter of shape (D,)
    - beta: Shift paremeter of shape (D,)
    - ln_param: Dictionary with the following keys:
        - eps: Constant for numeric stability

    Returns a tuple of:
    - out: of shape (N, D)
    - cache: A tuple of values needed in the backward pass
    """
    out, cache = None, None
    eps = ln_param.get("eps", 1e-5)
    ###########################################################################
    # TODO: Implement the training-time forward pass for layer norm.          #
    # Normalize the incoming data, and scale and  shift the normalized data   #
    #  using gamma and beta.                                                  #
    # HINT: this can be done by slightly modifying your training-time         #
    # implementation of  batch normalization, and inserting a line or two of  #
    # well-placed code. In particular, can you think of any matrix            #
    # transformations you could perform, that would enable you to copy over   #
    # the batch norm code and leave it almost unchanged?                      #
    ###########################################################################
    #compute the mean and variance
    mean = np.mean(x, axis=1, keepdims=True)
    var = np.var(x, axis=1, keepdims=True)

    #transform the original data
    x_norm = (x - mean) / np.sqrt(var + eps)
    out = x_norm * gamma + beta

    #fill the cache
    cache = {
          'x': x,
          'x_norm': x_norm,
          'mean': mean,
          'var': var,
          'gamma': gamma,
          'beta': beta,
          'eps': eps
    }
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    return out, cache


def layernorm_backward(dout, cache):
    """Backward pass for layer normalization.

    For this implementation, you can heavily rely on the work you've done already
    for batch normalization.

    Inputs:
    - dout: Upstream derivatives, of shape (N, D)
    - cache: Variable of intermediates from layernorm_forward.

    Returns a tuple of:
    - dx: Gradient with respect to inputs x, of shape (N, D)
    - dgamma: Gradient with respect to scale parameter gamma, of shape (D,)
    - dbeta: Gradient with respect to shift parameter beta, of shape (D,)
    """
    dx, dgamma, dbeta = None, None, None
    ###########################################################################
    # TODO: Implement the backward pass for layer norm.                       #
    #                                                                         #
    # HINT: this can be done by slightly modifying your training-time         #
    # implementation of batch normalization. The hints to the forward pass    #
    # still apply!                                                            #
    ###########################################################################
    #prepare variables
    N, D = dout.shape
    gamma = cache["gamma"]
    x_norm = cache["x_norm"]
    var = cache["var"]
    eps = cache["eps"]
    x = cache["x"]
    mean = cache["mean"]

    #compute gradients
    dxnorm = dout * gamma #shape(N, D)
    dgamma = np.sum(dout * x_norm, axis=0) #shape(D,)
    dbeta = np.sum(dout, axis=0) #shape(D,)
    dx =  1 / D / np.sqrt(var + eps) * (D * dxnorm - np.sum(dxnorm, axis=1, keepdims=True) - (x - mean) / (var + eps) * np.sum(dxnorm * (x - mean), axis=1, keepdims=True)) #just combine the three paths above
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    return dx, dgamma, dbeta


def dropout_forward(x, dropout_param):
    """Forward pass for inverted dropout.

    Note that this is different from the vanilla version of dropout.
    Here, p is the probability of keeping a neuron output, as opposed to
    the probability of dropping a neuron output.
    See http://cs231n.github.io/neural-networks-2/#reg for more details.

    Inputs:
    - x: Input data, of any shape
    - dropout_param: A dictionary with the following keys:
      - p: Dropout parameter. We keep each neuron output with probability p.
      - mode: 'test' or 'train'. If the mode is train, then perform dropout;
        if the mode is test, then just return the input.
      - seed: Seed for the random number generator. Passing seed makes this
        function deterministic, which is needed for gradient checking but not
        in real networks.

    Outputs:
    - out: Array of the same shape as x.
    - cache: tuple (dropout_param, mask). In training mode, mask is the dropout
      mask that was used to multiply the input; in test mode, mask is None.
    """
    p, mode = dropout_param["p"], dropout_param["mode"]
    if "seed" in dropout_param:
        np.random.seed(dropout_param["seed"])

    mask = None
    out = None

    if mode == "train":
        #######################################################################
        # TODO: Implement training phase forward pass for inverted dropout.   #
        # Store the dropout mask in the mask variable.                        #
        #######################################################################
        mask = (np.random.rand(*x.shape)<p).astype(x.dtype) #generate random number between [0,1], and <p helps determine 0 or 1. "*" means unpacking the tuple
        mask /= p #we should keep the expectation unchanged between training and test data, so we divide by p
        out = x * mask #randomly dropout
        #######################################################################
        #                           END OF YOUR CODE                          #
        #######################################################################
    elif mode == "test":
        #######################################################################
        # TODO: Implement the test phase forward pass for inverted dropout.   #
        #######################################################################
        mask = None
        out = x
        #######################################################################
        #                            END OF YOUR CODE                         #
        #######################################################################

    cache = (dropout_param, mask)
    out = out.astype(x.dtype, copy=False)

    return out, cache


def dropout_backward(dout, cache):
    """Backward pass for inverted dropout.

    Inputs:
    - dout: Upstream derivatives, of any shape
    - cache: (dropout_param, mask) from dropout_forward.
    """
    dropout_param, mask = cache
    mode = dropout_param["mode"]

    dx = None
    if mode == "train":
        #######################################################################
        # TODO: Implement training phase backward pass for inverted dropout   #
        #######################################################################
        dx = dout * mask
        #######################################################################
        #                          END OF YOUR CODE                           #
        #######################################################################
    elif mode == "test":
        dx = dout
    return dx


def conv_forward_naive(x, w, b, conv_param):
    """A naive implementation of the forward pass for a convolutional layer.

    The input consists of N data points, each with C channels, height H and
    width W. We convolve each input with F different filters, where each filter
    spans all C channels and has height HH and width WW.

    Input:
    - x: Input data of shape (N, C, H, W)
    - w: Filter weights of shape (F, C, HH, WW)
    - b: Biases, of shape (F,)
    - conv_param: A dictionary with the following keys:
      - 'stride': The number of pixels between adjacent receptive fields in the
        horizontal and vertical directions.
      - 'pad': The number of pixels that will be used to zero-pad the input.

    During padding, 'pad' zeros should be placed symmetrically (i.e equally on both sides)
    along the height and width axes of the input. Be careful not to modfiy the original
    input x directly.

    Returns a tuple of:
    - out: Output data, of shape (N, F, H', W') where H' and W' are given by
      H' = 1 + (H + 2 * pad - HH) / stride
      W' = 1 + (W + 2 * pad - WW) / stride
    - cache: (x, w, b, conv_param)
    """
    out = None
    ###########################################################################
    # TODO: Implement the convolutional forward pass.                         #
    # Hint: you can use the function np.pad for padding.                      #
    ###########################################################################
    N = x.shape[0] #number of images
    H = x.shape[2] #height of each image
    W = x.shape[3] #width of each image
    F = w.shape[0] #number of filters
    HH = w.shape[2] #height of filters
    WW = w.shape[3] #width of filters
    stride = conv_param["stride"]
    pad = conv_param["pad"]
    pad_width = ((0, 0), (0, 0), (pad, pad), (pad, pad)) #add pad on both sides of dimensions H and W 
    x_padded = np.pad(x, pad_width)
    H_out = 1 + (H + 2*pad - HH) // stride
    W_out = 1 + (W + 2*pad - WW) // stride
    out = np.zeros((N, F, H_out, W_out)) #initialize out
    for f in range(F):
      kernel = w[f]
      for i in range(0, H_out):
        for j in range(0, W_out):
          patch = x_padded[:, :, i*stride:i*stride+HH, j*stride:j*stride+WW] #slice x_padded on dimensions H and W
          out[:, f, i, j] = np.sum(patch * kernel, axis=(1, 2, 3)) + b[f] #convolution
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    cache = (x, w, b, conv_param)
    return out, cache


def conv_backward_naive(dout, cache):
    """A naive implementation of the backward pass for a convolutional layer.

    Inputs:
    - dout: Upstream derivatives.
    - cache: A tuple of (x, w, b, conv_param) as in conv_forward_naive

    Returns a tuple of:
    - dx: Gradient with respect to x
    - dw: Gradient with respect to w
    - db: Gradient with respect to b
    """
    dx, dw, db = None, None, None
    ###########################################################################
    # TODO: Implement the convolutional backward pass.                        #
    ###########################################################################

    #prepare the variables
    x, w, b, conv_param = cache
    stride = conv_param["stride"]
    pad = conv_param["pad"]
    N = x.shape[0]
    H = x.shape[2]
    W = x.shape[3]
    F = w.shape[0]
    HH = w.shape[2]
    WW = w.shape[3]
    H_out = 1 + (H + 2*pad - HH) // stride
    W_out = 1 + (W + 2*pad - WW) // stride
    pad_width = ((0, 0), (0, 0), (pad, pad), (pad, pad))
    x_padded = np.pad(x, pad_width)

    #initialize the gradients
    dx_padded = np.zeros_like(x_padded) #shape(N, C, H+2*pad, W+2*pad)
    dw = np.zeros_like(w) #shape(F, C, HH, WW)
    db = np.zeros_like(b) #shape(F,)

    #accumulate gradients
    for n in range(N):
      for f in range(F):
        db[f] += np.sum(dout[n, f])
        for i in range(H_out):
          for j in range(W_out):
            window = x_padded[n, :, i*stride:i*stride+HH, j*stride:j*stride+WW] #shape(C, HH, WW), which corresponds to the exact value in the output data
            dw[f] += window * dout[n, f, i, j] #shape(C, HH, WW)
            dx_padded[n, :, i*stride:i*stride+HH, j*stride:j*stride+WW] += w[f] * dout[n, f, i, j] #shape(C, HH, WW)
    dx =dx_padded[:, :, pad:pad+H, pad:pad+W] #get dx from cutting dx_padded
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    return dx, dw, db


def max_pool_forward_naive(x, pool_param):
    """A naive implementation of the forward pass for a max-pooling layer.

    Inputs:
    - x: Input data, of shape (N, C, H, W)
    - pool_param: dictionary with the following keys:
      - 'pool_height': The height of each pooling region
      - 'pool_width': The width of each pooling region
      - 'stride': The distance between adjacent pooling regions

    No padding is necessary here, eg you can assume:
      - (H - pool_height) % stride == 0
      - (W - pool_width) % stride == 0

    Returns a tuple of:
    - out: Output data, of shape (N, C, H', W') where H' and W' are given by
      H' = 1 + (H - pool_height) / stride
      W' = 1 + (W - pool_width) / stride
    - cache: (x, pool_param)
    """
    out = None
    ###########################################################################
    # TODO: Implement the max-pooling forward pass                            #
    ###########################################################################

    #prepare the variables
    N, C, H, W = x.shape
    pool_height = pool_param["pool_height"]
    pool_width = pool_param["pool_width"]
    stride = pool_param["stride"]
    H_out = 1 + (H - pool_height) // stride
    W_out = 1 + (W - pool_width) // stride
    out = np.zeros((N, C, H_out, W_out))

    #forward pass through each element in out of dimension H and W
    for i in range(0, H_out):
      for j in range(0, W_out):
        patch = x[:, :, i*stride:i*stride+pool_height, j*stride:j*stride+pool_width]
        out[:, :, i, j] = np.max(patch, axis=(2, 3))
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    cache = (x, pool_param)
    return out, cache


def max_pool_backward_naive(dout, cache):
    """A naive implementation of the backward pass for a max-pooling layer.

    Inputs:
    - dout: Upstream derivatives
    - cache: A tuple of (x, pool_param) as in the forward pass.

    Returns:
    - dx: Gradient with respect to x
    """
    dx = None
    ###########################################################################
    # TODO: Implement the max-pooling backward pass                           #
    ###########################################################################

    #prepare the variables
    x, pool_param = cache
    pool_height = pool_param["pool_height"]
    pool_width = pool_param["pool_width"]
    stride = pool_param["stride"]
    N, C, H, W = x.shape
    H_out = 1 + (H - pool_height) // stride
    W_out = 1 + (W - pool_width) // stride

    #initialize the gradient
    dx = np.zeros_like(x)

    #backward pass
    for n in range(N):
      for c in range(C):
        for i in range(H_out):
          for j in range(W_out):
            window = x[n, c, i*stride:i*stride+pool_height, j*stride:j*stride+pool_width]
            max_index = np.unravel_index(np.argmax(window), window.shape) #np.argmax returns flattened index, and np.unravel_index reshapes the index in the multidimensional array
            max_h, max_w = max_index
            dx[n, c, i*stride+max_h, j*stride+max_w] += dout[n, c, i, j] #be careful that we cannot use "=" instead because different pooling regions may have same max positions
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    return dx


def spatial_batchnorm_forward(x, gamma, beta, bn_param):
    """Computes the forward pass for spatial batch normalization.

    Inputs:
    - x: Input data of shape (N, C, H, W)
    - gamma: Scale parameter, of shape (C,)
    - beta: Shift parameter, of shape (C,)
    - bn_param: Dictionary with the following keys:
      - mode: 'train' or 'test'; required
      - eps: Constant for numeric stability
      - momentum: Constant for running mean / variance. momentum=0 means that
        old information is discarded completely at every time step, while
        momentum=1 means that new information is never incorporated. The
        default of momentum=0.9 should work well in most situations.
      - running_mean: Array of shape (D,) giving running mean of features
      - running_var Array of shape (D,) giving running variance of features

    Returns a tuple of:
    - out: Output data, of shape (N, C, H, W)
    - cache: Values needed for the backward pass
    """
    out, cache = None, None

    ###########################################################################
    # TODO: Implement the forward pass for spatial batch normalization.       #
    #                                                                         #
    # HINT: You can implement spatial batch normalization by calling the      #
    # vanilla version of batch normalization you implemented above.           #
    # Your implementation should be very short; ours is less than five lines. #
    ###########################################################################
    N, C, H, W = x.shape #get all the variables
    x_reshaped = x.transpose(0, 2, 3, 1).reshape(-1, C) #reshape the input into shape(C, N*H*W), which corresponds to the vanilla bn input shape(N, D)
    out, cache = batchnorm_forward(x_reshaped, gamma, beta, bn_param)
    out = out.reshape(N, H, W, C).transpose(0, 3, 1, 2) #recover
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################

    return out, cache


def spatial_batchnorm_backward(dout, cache):
    """Computes the backward pass for spatial batch normalization.

    Inputs:
    - dout: Upstream derivatives, of shape (N, C, H, W)
    - cache: Values from the forward pass

    Returns a tuple of:
    - dx: Gradient with respect to inputs, of shape (N, C, H, W)
    - dgamma: Gradient with respect to scale parameter, of shape (C,)
    - dbeta: Gradient with respect to shift parameter, of shape (C,)
    """
    dx, dgamma, dbeta = None, None, None

    ###########################################################################
    # TODO: Implement the backward pass for spatial batch normalization.      #
    #                                                                         #
    # HINT: You can implement spatial batch normalization by calling the      #
    # vanilla version of batch normalization you implemented above.           #
    # Your implementation should be very short; ours is less than five lines. #
    ###########################################################################
    N, C, H, W = dout.shape #get all the variables
    dout_reshaped = dout.transpose(0, 2, 3, 1).reshape(-1, C) #reshape the input into shape(C, N*H*W), which corresponds to the vanilla bn input shape(N, D)
    dx, dgamma, dbeta = batchnorm_backward_alt(dout_reshaped, cache)
    dx = dx.reshape(N, H, W, C).transpose(0, 3, 1, 2) #recover
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################

    return dx, dgamma, dbeta


def spatial_groupnorm_forward(x, gamma, beta, G, gn_param):
    """Computes the forward pass for spatial group normalization.
    
    In contrast to layer normalization, group normalization splits each entry in the data into G
    contiguous pieces, which it then normalizes independently. Per-feature shifting and scaling
    are then applied to the data, in a manner identical to that of batch normalization and layer
    normalization.

    Inputs:
    - x: Input data of shape (N, C, H, W)
    - gamma: Scale parameter, of shape (1, C, 1, 1)
    - beta: Shift parameter, of shape (1, C, 1, 1)
    - G: Integer mumber of groups to split into, should be a divisor of C
    - gn_param: Dictionary with the following keys:
      - eps: Constant for numeric stability

    Returns a tuple of:
    - out: Output data, of shape (N, C, H, W)
    - cache: Values needed for the backward pass
    """
    out, cache = None, None
    eps = gn_param.get("eps", 1e-5)
    ###########################################################################
    # TODO: Implement the forward pass for spatial group normalization.       #
    # This will be extremely similar to the layer norm implementation.        #
    # In particular, think about how you could transform the matrix so that   #
    # the bulk of the code is similar to both train-time batch normalization  #
    # and layer normalization!                                                #
    ###########################################################################

    N, C, H, W = x.shape #get all the variables
    x_group = x.reshape(N, G, C//G, H, W) #reshape the data according to groups

    #compute the mean and variance
    mean = np.mean(x_group, axis=(2,3,4), keepdims=True) #shape(N, G, 1, 1, 1)
    var = np.var(x_group, axis=(2,3,4), keepdims=True) #shape(N, G, 1, 1, 1)

    #transform the original data
    x_group_norm = (x_group - mean) / np.sqrt(var + eps)
    x_norm = x_group_norm.reshape(N, C, H, W)
    out = x_norm * gamma + beta #be careful that gamma and beta are of shape(1, C, 1, 1)

    #fill the cache
    cache = {
          'G': G,
          'x': x,
          'x_norm': x_norm,
          'mean': mean,
          'var': var,
          'gamma': gamma,
          'beta': beta,
          'eps': eps
    }
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    return out, cache


def spatial_groupnorm_backward(dout, cache):
    """Computes the backward pass for spatial group normalization.

    Inputs:
    - dout: Upstream derivatives, of shape (N, C, H, W)
    - cache: Values from the forward pass

    Returns a tuple of:
    - dx: Gradient with respect to inputs, of shape (N, C, H, W)
    - dgamma: Gradient with respect to scale parameter, of shape (1, C, 1, 1)
    - dbeta: Gradient with respect to shift parameter, of shape (1, C, 1, 1)
    """
    dx, dgamma, dbeta = None, None, None

    ###########################################################################
    # TODO: Implement the backward pass for spatial group normalization.      #
    # This will be extremely similar to the layer norm implementation.        #
    ###########################################################################
    #prepare variables
    N, C, H, W = dout.shape
    G = cache["G"]
    x = cache["x"]
    x_norm = cache["x_norm"]
    mean = cache["mean"]
    var = cache["var"]
    gamma = cache["gamma"]
    eps = cache["eps"]

    #compute gradients
    dxnorm = dout * gamma #shape(N, C, H, W)
    dgamma = np.sum(dout * x_norm, axis=(0,2,3), keepdims=True) #shape(1, C, 1, 1)
    dbeta = np.sum(dout, axis=(0,2,3), keepdims=True) #shape(1, C, 1, 1)
    dx_groupnorm = dxnorm.reshape(N, G, C//G, H, W)
    x_group = x.reshape(N, G, C//G, H, W)
    dx_group =  1 / (C // G * H * W) / np.sqrt(var + eps) * ((C // G * H * W) * dx_groupnorm - np.sum(dx_groupnorm, axis=(2,3,4), keepdims=True) - (x_group - mean) / (var + eps) * np.sum(dx_groupnorm * (x_group - mean), axis=(2,3,4), keepdims=True)) #just combine the three paths above
    dx = dx_group.reshape(N, C, H, W)
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    return dx, dgamma, dbeta
